"use strict"

pages.avatar = () => {
    // Temporary \\
}